Zip file contains the infected wordfile with Emotet Malware 
Use password:infected 
to unzip the file